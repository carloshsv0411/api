from flask import Flask
from flask_cors import CORS

from controllers.user_controller import user_routes
from controllers.livro_controller import livro_routes
from controllers.emprestimo_controller import emprestimo_routes
from controllers.avaliacao_controller import avaliacao_routes

def create_app():
    app = Flask(__name__)
    CORS(app)

    # Registrando rotas com prefixos de API
    app.register_blueprint(user_routes, url_prefix="/api/users")
    app.register_blueprint(livro_routes, url_prefix="/api/livros")
    app.register_blueprint(emprestimo_routes, url_prefix="/api/emprestimos")
    app.register_blueprint(avaliacao_routes, url_prefix="/api/avaliacoes")

    return app

# Heroku/Gunicorn vai usar essa variável
app = create_app()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
